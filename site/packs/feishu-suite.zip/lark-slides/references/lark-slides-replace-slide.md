# slides +replace-slide（兼容入口）

本文档已迁移至 [`references/cli/lark-slides-replace-slide.md`](cli/lark-slides-replace-slide.md)。

此文件仅保留旧路径兼容性；后续引用请使用新路径。
