# slides +xml-get（单页读取兼容入口）

本文档已合并至 [`references/cli/lark-slides-xml-presentations-get.md`](references/cli/lark-slides-xml-presentations-get.md)。

此文件保留旧路径兼容性；后续引用请使用 `cli/` 下的正式 reference。
