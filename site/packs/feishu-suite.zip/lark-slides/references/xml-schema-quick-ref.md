# XML Schema 快速参考（兼容入口）

本文档已迁移至 [`references/xml/xml-schema-quick-ref.md`](references/xml/xml-schema-quick-ref.md)。

此文件仅保留旧路径兼容性；后续引用请使用新路径。
