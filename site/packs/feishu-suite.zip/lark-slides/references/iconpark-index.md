# IconPark 图标索引（兼容入口）

本文档已迁移至 [`xml/iconpark-index.json`](xml/iconpark-index.json)。

此文件仅保留旧路径兼容性；后续引用请使用新路径。
