# slides +screenshot（兼容入口）

本文档已迁移至 [`references/cli/lark-slides-screenshot.md`](references/cli/lark-slides-screenshot.md)。

此文件仅保留旧路径兼容性；后续引用请使用新路径。
