# Sources & Methodology

- 技能：`epub-builder`（awesome-skillkit 原创编写，Apache-2.0）。
- 定位：场景包 `office` 的补强技能。`office` 原有 `docx-writer`（Word）与
  `pdf-pipeline`（PDF），缺一个「可重排的电子书」出口，本技能补齐这一格。

## 方法论借鉴（仅思想与规范事实，未复制任何文本或代码）

| 来源 | 许可证 | 借鉴的规范要点 |
|---|---|---|
| EPUB 3 规范（W3C / IDPF 公开文档） | W3C 文档许可 | 包结构（mimetype / META-INF / OEBPS）、`container.xml` 的 rootfile 指向、OPF 的 manifest 与 spine 分工 |
| EPUB 2 的 NCX 目录约定（DAISY 公开规范） | 公开规范 | `toc.ncx` 为老阅读器提供目录，需与 EPUB3 的 `nav.xhtml` 并存 |
| Markdown 公开语法说明 | 见原文 | 标题/列表/引用/代码块/表格/行内强调的基础语义 |
| 通用 ZIP 文件格式公开说明 | 公开规范 | `mimetype` 需为第一条目且不压缩（STORED），这是 EPUB 的 OCF 层硬性要求 |
| 本仓库既有技能规范（docs/ 下 SKILL-STANDARD-v2） | Apache-2.0 | 骨架章节、失败处置表、子命令化与可验证交付标准 |

上述来源全部作为**规范事实与结构骨架**被使用。`scripts/epub_build.py` 的
Markdown 解析器、OPF/NCX/NAV 的三份 XML 模板、`slugify` 命名规则、
章节切分逻辑与 inspect 回读实现，均为从零撰写，
No upstream passage, example, or code was translated, rewritten, or excerpted.

## Key design decisions (why this way)

1. **只用标准库**：EPUB 是「zip + XML」，`zipfile` 与 `xml.etree.ElementTree`
   已足够。引入第三方库会让技能在裸环境下失效，而收益接近于零。
2. **`mimetype` 写入顺序被当作一等公民**：构建时用 `ZipInfo` 显式指定
   `ZIP_STORED` 并第一个写入，且 `build` 结束前重新打开文件自查一遍——
   这是最容易出错、且出错后**最难从表面察觉**的一步（文件能生成、大小正常，
   但阅读器拒收）。
3. **固定 ZIP 时间戳**：`ZIP_TIMESTAMP = (1980,1,1,0,0,0)`，
   使同样的输入产出**逐字节可复现**的文件，便于比对与版本控制。
4. **章节顺序读 spine 而非 manifest**：manifest 只是资源清单，顺序无规范保证；
   spine 才定义阅读顺序。inspect 按 spine 输出，与阅读器行为一致。
5. **同时生成 toc.ncx 与 nav.xhtml**：新老阅读器各认一份，缺一则部分设备无目录。
6. **UID 用 `uuid5` 由书名+作者+章节数派生**：同一本书重复构建得到相同
   `dc:identifier`，避免每次构建都被阅读器当成新书而重建阅读进度。
7. **不做花哨样式**：EPUB 的最终排版由阅读器与用户设置主导，
   过度指定 CSS 会在不同设备上崩版。只提供最小可读样式。
8. **不含图片支持且明确说明**：不假装支持。图片需要资源清单、媒体类型与
   相对路径管理，属于另一个技能的范围，含糊承诺比直说「不支持」更有害。

## Limitations and boundaries

- **不支持图片与封面**：仅处理文本结构。需要插图请另行加工。
- **章节切分只认 H1**：不识别「第一章」等中文序数模式；用户应按 H1 组织原稿。
- **Markdown 子集**：支持标题/列表/引用/代码块/表格/行内强调/链接/分隔线；
  不支持脚注、数学公式、定义列表、HTML 内嵌。
- **不做 EPUB 校验器级别检查**：不实现 epubcheck 的全部规则（如
  `dc:identifier` 的 URI 规范形式、媒体类型白名单的完整校验）。
  需要发布级校验应另跑 epubcheck。
- **中文字体不嵌入**：依赖阅读器的字体回退，不打包字体文件。

## License

This skill and its reference files are distributed under Apache-2.0; the upstream documents listed carry their own license terms, which do not apply to this file.
