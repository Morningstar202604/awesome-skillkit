# Sources and Methodology

This skill is self-authored; its methodology skeleton is distilled from the following public materials (structural borrowing only, no text copied):

| Source | Type | What was borrowed | License/attribution |
|------|------|----------|-----------|
| 豆包官方教程与《豆包进阶手册》系列（五要素公式：身份+场景+任务+要求+格式） | 🟡 第三方聚合（ima 知识库收录） | task 模式五要素、三步框架（背景定位→目标明确→要求细化） | 结构性方法论引用，已注明出处 |
| 《豆包，总结出 5 条"最强指令"》（头条实测文，2026-09） | 🟡 第三方 | 反向约束纪律（禁用词表、字数硬限、"每句有信息量"）、三轮迭代法（骨架→血肉→抛光）、角色锚定+输出格式锁定 | 结构性方法论引用，已注明出处 |
| Coze 扣子官方文档（人设与回复逻辑：人物设定/功能和流程/约束与限制/回复格式四段式） | 🟢 官方 | agent 模式五段骨架的直接前身（本技能在四段基础上拆出"边界处理"独立成段） | 官方文档结构引用，已注明出处 |
| Coze 社区最佳实践（五模块：Role/Context/Skills&Tools/Workflow/Output） | 🟡 第三方 | "工作流 Step-by-Step 是智能体变聪明的核心"、能力定义三要素（何时触发+怎么做+返回什么） | 结构性方法论引用，已注明出处 |
| CO-STAR 框架（Context/Objective/Steps/Tone/Audience） | 🟡 第三方 | agent 模式五段的英文命名对照 | 框架名引用，已注明出处 |

## Design decisions

1. **与 video-prompt-engineer 同构**：五要素之于聊天 = 六槽位之于视频。同一套
   "缺槽就自由发挥 → 自由发挥即废稿"的心智模型，用户学一次跨场景复用。
2. **边界处理独立成段**：Coze 官方四段式没有兜底节，但实测中"超出范围反问/
   不编造"是智能体幻觉的第一道闸，值得独立成段强制审计。
3. **反向约束前置**：官方教程把要求放第四位，本技能在写法上把反向约束排在要求段
   首位——它是砍套话最有效的一刀。
4. **启发式审计而非语义评分**：与仓库 video 侧同款哲学——脚本管结构完整性，
   人管选词质量。两层检查，缺一不可。

## 核实义务

所有方言条目（platform-dialects.md）均标注来源分级与核实方法，使用前必须
重新核实——模型生态月度级变化，本文件不豁免 VERIFY BEFORE USE。
