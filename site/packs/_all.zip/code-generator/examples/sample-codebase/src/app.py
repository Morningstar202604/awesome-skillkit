def hello():
    return "hi"
