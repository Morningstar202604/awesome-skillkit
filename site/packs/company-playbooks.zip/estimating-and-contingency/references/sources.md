# Sources — `pmo:estimating-and-contingency`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## GAO Cost Estimating and Assessment Guide

US Government Accountability Office · US · public domain (US government) — quote freely

<https://www.gao.gov/products/gao-20-195g>

Machine-readable: <https://www.gao.gov/assets/gao-20-195g.pdf>

**Authoritative for:** What makes a cost estimate defensible, and specifically how much contingency is justified — via risk and uncertainty analysis at a stated confidence level, rather than a percentage somebody remembers.

## The Green Book: appraisal and evaluation in central government

HM Treasury · UK · free to use with attribution — credit the publisher

<https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-governent>

**Authoritative for:** Whether a claimed benefit may be counted at all — what separates a benefit from a transfer, how optimism bias is corrected for, and what a business case must contain. The best free treatment of benefits discipline anywhere, and openly licensed.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
