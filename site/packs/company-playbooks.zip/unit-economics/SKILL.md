---
name: unit-economics
description: >-
  Establishes whether the business makes money on each customer or unit —
  contribution margin, acquisition cost, payback period, lifetime value, and
  the cohort behavior underneath. Use this to assess whether growth is
  profitable, evaluate a channel or segment, support a pricing decision,
  judge how fast the business can afford to grow, or diagnose why revenue
  growth is not producing profit.
description_zh: "单客与单位经济性：贡献毛利、获客成本、回收期、LTV 与关键杠杆测算。"
license: MIT
compatibility: 纯提示型；涉及财务、合规或法律判断时建议人工复核。
metadata:
  author: "cbrock84/headcount 上游（MIT）"
  version: "1.0.0"
  category: finance
  pattern: single-task
  tier: standard
  verified-date: "2026-09-27"
  source: "https://github.com/cbrock84/headcount/tree/main/plugins/finance/skills/unit-economics"
---

# Unit economics

The question is simple and usually unanswered: does one more customer make the business better off,
and how long does that take?

## Build it in this order

1. **Define the unit.** A customer, an account, a seat, an order. State it, because most
   disagreements about unit economics are disagreements about the unit.
2. **Contribution margin** — revenue per unit minus the costs that vary with it. Include everything
   that actually varies: payment processing, hosting attributable to usage, support load, delivery,
   third-party fees. Understating variable cost is the single most common error and it flatters
   everything downstream.
3. **Acquisition cost** — fully loaded. All sales and marketing spend, including salaries, divided
   by customers acquired in the same period. Excluding people costs is the second most common error
   and typically understates by half or more.
4. **Payback period** — acquisition cost divided by monthly contribution. This is the number that
   governs how fast you can grow without financing it.
5. **Lifetime value** — contribution × expected lifetime, from observed retention. Not from a
   churn-rate assumption chosen because it produces a good ratio.

## Read it honestly

- **Ratios hide the constraint.** A healthy lifetime-value ratio with a long payback still means
  growth consumes cash faster than it produces it. Payback governs the growth rate; the ratio
  governs whether it is worth doing at all.
- **Segment before concluding.** Blended economics almost always conceal one segment subsidizing
  another. The average is the least useful number.
- **Use cohorts, not averages.** Retention improves or decays over time, and blended figures mask
  which. If early cohorts retain better than recent ones, the business is deteriorating while the
  average looks stable.
- **Do not extrapolate lifetime beyond your data.** A twelve-month-old company cannot observe a
  three-year lifetime, and assuming one is how unprofitable businesses appear profitable.

## What it should change

Good unit economics by segment tell you where to spend. Bad ones tell you to fix the model before
scaling — no acquisition efficiency rescues a negative contribution margin, it only reaches the
loss faster.

## Sources

`references/sources.md` in this skill lists the outside authorities that settle the questions
here — what each one is authoritative for, and what you may do with it. Check them before
answering on anything they cover, and cite what you used. Most are free to read and not free
to reproduce; the use note on each is binding.

## Never

- Compare acquisition cost against revenue rather than contribution.
- Report lifetime value without stating the retention data behind it and its observation window.
- Treat improving ratios as progress without checking whether the mix simply shifted.

---

## 来源与署名 / Source & Attribution

本技能收录自 [cbrock84/headcount](https://github.com/cbrock84/headcount/tree/main/plugins/finance/skills/unit-economics)（MIT）；awesome-skillkit 仅做规范化（frontmatter 归一、补中文描述、路径与链接清理）与署名，内容与更新以上游为准。
