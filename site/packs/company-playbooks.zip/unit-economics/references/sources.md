# Sources — `finance:unit-economics`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## Commission Guidance on Management's Discussion and Analysis, Release 33-10751

US Securities and Exchange Commission · US · public domain (US government) — quote freely

<https://www.federalregister.gov/documents/2020/02/25/2020-02296/commission-guidance-on-managements-discussion-and-analysis-of-financial-condition-and-results-of>

**Authoritative for:** What a company must do when it publishes an operating metric — define it, disclose how it is calculated, apply it consistently, and explain any change in method. It disciplines metrics like recurring revenue and net retention without defining them, which is the honest ceiling on authority here.

## Non-GAAP financial measures — compliance and disclosure interpretations

US Securities and Exchange Commission, Division of Corporation Finance · US · public domain (US government) — quote freely

<https://www.sec.gov/corpfin/non-gaap-financial-measures>

**Authoritative for:** When a non-GAAP measure becomes misleading and therefore prohibited — individually tailored recognition, excluding normal operating costs, improper labeling, and the equal-prominence requirement.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
