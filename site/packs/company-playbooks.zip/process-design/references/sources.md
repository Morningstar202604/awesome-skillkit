# Sources — `operations:process-design`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## 9 CFR Part 417 — Hazard Analysis and Critical Control Point systems

US Department of Agriculture, Food Safety and Inspection Service · US · public domain (US government) — quote freely

<https://www.ecfr.gov/current/title-9/chapter-III/subchapter-E/part-417>

**Authoritative for:** What a HACCP plan must contain for meat and poultry — control points, critical limits, monitoring, corrective action and reassessment. A different regulator from the FDA, and which one governs depends on the product.

## ISO 9001 — Quality management systems: requirements

ISO · global · **sold — cite the identifier only, never the text**

<https://www.iso.org/standard/62085.html>

**Authoritative for:** Whether a quality system is certifiable — the auditable requirements a nonconformity procedure or management review is judged against. Sold, so cite the clause number and never the wording.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
