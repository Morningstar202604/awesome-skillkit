# Sources — `corporate-strategy:market-entry`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## Country Commercial Guides

US Department of Commerce, International Trade Administration · global · public domain (US government) — quote freely

<https://www.trade.gov/country-commercial-guides>

**Authoritative for:** The factual regulatory picture for entering a named foreign market — licensing, customs, standards, distribution and investment restrictions. It settles the factual questions in a market entry, not the strategic ones.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
