---
name: market-entry
description: >-
  Decides whether and how to enter a new market — sizing demand from the
  bottom up rather than from a market report, testing whether your advantage
  transfers, choosing between organic entry, partnership and acquisition,
  sequencing the operational and regulatory work that entry actually
  requires, and setting the criteria that would tell you to stop. Use this
  to evaluate a new geography, segment or vertical, pressure-test an entry
  plan, or work out why a launched market never reached scale.
description_zh: "判断是否与如何进入新市场：自下而上估算需求，验证优势可迁移性并定进入方式。"
license: MIT
compatibility: 纯提示型；涉及财务、合规或法律判断时建议人工复核。
metadata:
  author: "cbrock84/headcount 上游（MIT）"
  version: "1.0.0"
  category: leadership
  pattern: single-task
  tier: standard
  verified-date: "2026-09-27"
  source: "https://github.com/cbrock84/headcount/tree/main/plugins/corporate-strategy/skills/market-entry"
---

# Market entry

Entry decisions are usually made on the size of the opportunity and lost on the cost of serving it.
The market was real; what was underestimated was everything required to operate there.

## Size from the bottom up, then check it against the top down

A market report gives you a number that includes companies who will never buy from you. Build the
estimate from countable things: how many organizations fit your profile, how many have the problem
acutely, what they spend on it today, what share you could plausibly hold in a defined period.

Use a top-down figure only as a sanity check. If bottom-up and top-down differ by an order of
magnitude, one of them contains an assumption nobody has stated, and finding it is the most
valuable hour in the analysis.

## Test whether the advantage actually transfers

The question is not whether the market is attractive — attractive markets are attractive to
everyone, including incumbents already there. The question is what you have that wins.

Advantages transfer unevenly. Product capability usually transfers. Brand rarely does across
geographies. Distribution and relationships almost never do. Cost structure may invert entirely.
An entry justified by "we are strong in the adjacent market" needs to name the specific thing that
carries over, and it is usually less than assumed.

**Ask why the incumbent has not already done what you plan to do.** Either they cannot, which is
your advantage, or they have found it does not work, which is your warning.

## Choose the entry mode against speed, control and reversibility

- **Organic** — full control, slowest, and every local capability has to be built. Right when the
  advantage is the product and the market is reachable with your existing motion.
- **Partnership or distribution** — fast and cheap, and you learn less. Right when local
  relationships are the barrier and you can accept less control of the customer relationship.
- **Acquisition** — buys presence and capability immediately, at the highest price and with the
  integration risk. Right when time matters more than money and the target has something you cannot
  build quickly.

Ask what each mode costs to unwind. Organic entry can be stopped. A distribution agreement with a
long term and exclusivity cannot, and a bad partner can foreclose the market for years.

## Scope the operating cost honestly, including the parts that are not strategy

This is where entry plans are optimistic. Entity setup and tax registration, employment obligations,
data residency and privacy regimes, sector licensing, payment methods and currency, local-language
support hours, contract terms that differ from your standard, and localized documentation.

Each is individually manageable and collectively a program. Get someone who has actually operated in
the market to review the list before committing, because the item you have not thought of is
usually the expensive one.

## Sequence for a real test, not for a full launch

Enter narrowly enough that failure is affordable and informative: one segment, one channel, a small
number of reference customers. A full launch commits the spend before you know whether the thesis
holds.

Define what you are trying to learn and what result would count as the thesis failing. Entry
without a disconfirming condition becomes a market you stay in because you are already there.

## Set the stopping criteria before you start

Write down what would have to be true by when, and what you will do if it is not. Markets rarely
fail loudly; they underperform quietly while absorbing management attention that the core business
was producing better returns on.

Review against the criteria on the date, not when someone finally raises it.

## Sources

`references/sources.md` in this skill lists the outside authorities that settle the questions
here — what each one is authoritative for, and what you may do with it. Check them before
answering on anything they cover, and cite what you used. Most are free to read and not free
to reproduce; the use note on each is binding.

## Never

- Size a market from a published figure without building it up from countable units.
- Justify entry on an advantage nobody has named specifically.
- Sign an exclusive distribution agreement before you understand the market.
- Enter without a written condition that would tell you to stop.

---

## 来源与署名 / Source & Attribution

本技能收录自 [cbrock84/headcount](https://github.com/cbrock84/headcount/tree/main/plugins/corporate-strategy/skills/market-entry)（MIT）；awesome-skillkit 仅做规范化（frontmatter 归一、补中文描述、路径与链接清理）与署名，内容与更新以上游为准。
