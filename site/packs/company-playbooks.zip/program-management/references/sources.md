# Sources — `pmo:program-management`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## GAO Cost Estimating and Assessment Guide

US Government Accountability Office · US · public domain (US government) — quote freely

<https://www.gao.gov/products/gao-20-195g>

Machine-readable: <https://www.gao.gov/assets/gao-20-195g.pdf>

**Authoritative for:** What makes a cost estimate defensible, and specifically how much contingency is justified — via risk and uncertainty analysis at a stated confidence level, rather than a percentage somebody remembers.

## NASA Systems Engineering Handbook

NASA · US · public domain (US government) — quote freely

<https://www.nasa.gov/reference/systems-engineering-handbook/>

**Authoritative for:** What a phase gate must contain before a technical project may proceed — the review structure, entrance and success criteria, and how the technical baseline is controlled.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
