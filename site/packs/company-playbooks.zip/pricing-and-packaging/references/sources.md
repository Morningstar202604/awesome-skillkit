# Sources — `revenue:pricing-and-packaging`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## 15 U.S.C. 8403 — Restore Online Shoppers' Confidence Act

US Congress, via the Office of the Law Revision Counsel · US · public domain (US government) — quote freely

<https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title15-section8403&num=0&edition=prelim>

**Authoritative for:** Whether an online auto-renewal offer is lawful — clear disclosure of material terms before billing, express informed consent, and a simple cancellation mechanism. This area has seen rules issued and struck down, so cite the statute rather than a rule summary.

## App Store Review Guidelines

Apple · global · **read and cite only — copyrighted, do not reproduce**

<https://developer.apple.com/app-store/review/guidelines/>

Machine-readable: <https://developer.apple.com/app-store/search/>

**Authoritative for:** Whether a listing, screenshot set, price presentation or subscription flow will be rejected. Binding for anything shipping through the App Store, and copyrighted — cite the rule number, do not mirror the text.

## California Automatic Renewal Law, Business and Professions Code 17600-17606

California Legislative Counsel · US-CA · public domain — quote freely

<https://leginfo.legislature.ca.gov/faces/codes_displayText.xhtml?division=7.&chapter=1.&part=3.&lawCode=BPC&article=9.>

**Authoritative for:** The concrete cancellation obligations a subscription business actually has to meet, because California's requirements are stricter than the federal floor and apply to any California customer — which in practice makes them the binding ones.

## FASB Accounting Standards Codification

Financial Accounting Standards Board · US · **account required — cite it; the user fetches it**

<https://asc.fasb.org/>

**Authoritative for:** US GAAP as it actually reads — revenue recognition, leases, impairment. The Basic View is free with an account and the text is copyrighted: cite the ASC number, do not reproduce the wording.

## Guides Against Deceptive Pricing, 16 CFR 233

US Federal Trade Commission · US · public domain (US government) — quote freely

<https://www.ecfr.gov/current/title-16/chapter-I/subchapter-B/part-233>

**Authoritative for:** Whether a 'was $X, now $Y', list-price, free-offer or percentage-off claim is lawful as presented.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
