---
name: pricing-and-packaging
description: >-
  Sets price, structures packages and tiers, and designs the monetization
  surfaces that carry them — upgrade paths, paywalls, and offer
  construction. Use this to set or change pricing, design or restructure
  tiers, choose a pricing metric, build an offer, design upgrade prompts and
  paywalls, or evaluate whether a pricing change is safe to make.
description_zh: "定价与套餐设计：分层、升级路径、付费墙与优惠构造，把价值映射到价格。"
license: MIT
compatibility: 纯提示型；涉及财务、合规或法律判断时建议人工复核。
metadata:
  author: "cbrock84/headcount 上游（MIT）"
  version: "1.0.0"
  category: product
  pattern: single-task
  tier: standard
  verified-date: "2026-09-27"
  source: "https://github.com/cbrock84/headcount/tree/main/plugins/revenue/skills/pricing-and-packaging"
---

# Pricing and packaging

The highest-leverage number in the business and the least examined. Most companies are underpriced
and have never tested it.

## The pricing metric

Choose what you charge *per* before choosing how much. It should scale with the value the customer
receives, be predictable enough to budget, and be something they cannot easily game.

Get this wrong and no amount of tuning the number fixes it — a metric that scales with your cost
rather than their value creates a permanent argument at every renewal.

## Setting the level

Anchor on value delivered, not cost incurred. Cost sets a floor and nothing else.

Evidence to gather: what the alternative costs them today including labor, what similar categories
charge, and what current customers say about price — with the caveat that nobody says a price is too
low. Willingness-to-pay research is directional, not decisive; people misreport.

If nobody ever objects to your price, it is too low. Some loss on price is correct.

## Packaging

Tiers should map to distinguishable segments with different needs, not to arbitrary feature counts.
Three is usually right; more creates paralysis and support load.

Each tier needs one obvious reason to upgrade, tied to something that grows with the customer's
success. Gating on a feature they will never need does not drive upgrades; gating on a limit they
will hit does.

Name tiers for who they are for, not by metal. "Team" and "Business" tell a buyer where they belong.

## Monetization surfaces

Upgrade prompts and paywalls should appear at the moment of blocked value — when someone is trying
to do the thing the tier does not allow, not on a schedule.

Explain what is behind the gate and why the limit exists. An unexplained wall reads as extraction.
Show the value already received before asking for payment, and make declining easy — dark patterns
buy one conversion and lose the account.

## Changing price

- Grandfather existing customers, or expect churn well beyond the price-sensitive segment.
- Announce with real notice and a clear reason.
- Change one thing at a time — price and packaging together makes the result unreadable.
- Model the downside first: at what churn rate does this increase lose money?

## Sources

`references/sources.md` in this skill lists the outside authorities that settle the questions
here — what each one is authoritative for, and what you may do with it. Check them before
answering on anything they cover, and cite what you used. Most are free to read and not free
to reproduce; the use note on each is binding.

## Never

- Change price without telling existing customers before it takes effect and honoring what they already signed.
- Pick a pricing metric the customer cannot predict. If they cannot forecast the bill, they will not sign.
- Add a tier to close a single deal. Tiers are a permanent tax on every conversation after it.
- Discount without taking something back in exchange — term, scope, payment timing, a reference. A free discount resets the price for everyone.

---

## 来源与署名 / Source & Attribution

本技能收录自 [cbrock84/headcount](https://github.com/cbrock84/headcount/tree/main/plugins/revenue/skills/pricing-and-packaging)（MIT）；awesome-skillkit 仅做规范化（frontmatter 归一、补中文描述、路径与链接清理）与署名，内容与更新以上游为准。
