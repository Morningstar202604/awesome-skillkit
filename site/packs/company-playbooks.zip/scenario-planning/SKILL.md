---
name: scenario-planning
description: >-
  Plans under genuine uncertainty — building scenarios, identifying which
  assumptions are load-bearing, setting early-warning indicators, and
  stress-testing a plan against futures rather than forecasting one. Use
  this when a decision depends on something unknowable, when a plan assumes
  conditions that may not hold, before a large irreversible commitment, or
  when a market, regulatory, or technology shift could invalidate the
  strategy.
description_zh: "在真实不确定下做情景规划：构建情景、找承重假设、设早期预警指标并做压力测试。"
license: MIT
compatibility: 纯提示型；涉及财务、合规或法律判断时建议人工复核。
metadata:
  author: "cbrock84/headcount 上游（MIT）"
  version: "1.0.0"
  category: leadership
  pattern: single-task
  tier: standard
  verified-date: "2026-09-27"
  source: "https://github.com/cbrock84/headcount/tree/main/plugins/corporate-strategy/skills/scenario-planning"
---

# Scenario planning

Forecasting produces one number and false confidence. Scenario planning produces a plan that
survives being wrong, which is the realistic goal.

## Separate what you know from what you are assuming

List the plan's assumptions explicitly, then sort them:

- **Predetermined** — things that will happen regardless. Demographics, contracted commitments,
  technology already deployed. Plan around them; do not spend analysis on them.
- **Genuinely uncertain and load-bearing** — the plan changes materially depending on how they
  resolve.

Almost every plan has **two or three** load-bearing uncertainties. Finding them is most of the
value, and the exercise usually surfaces one nobody had articulated.

## Build scenarios from the uncertainties, not from moods

The common failure is three scenarios named optimistic, base, and pessimistic — which is one scenario
with the numbers scaled, and it teaches nothing.

Take the two most consequential uncertainties and build the quadrants. Each scenario should be
internally coherent: if demand is high *and* supply is constrained, what else follows — pricing,
competitor behavior, regulatory attention?

Give each a name that captures its logic. Names make scenarios usable in conversation, which is where
they earn their keep.

Three or four scenarios. More cannot be held in mind; two collapses into best and worst.

## Stress-test the plan against each

For every scenario: does the plan still work, what breaks first, and what would we wish we had done
sooner?

The output is not a prediction. It is three things:

- **Robust moves** — sensible in every scenario. Do these now, with confidence.
- **Contingent moves** — right in some scenarios only. Prepare, do not commit.
- **Options** — small investments that buy the right to act later. Deliberately underrated, because
  they look like indecision and are actually the cheapest way to handle uncertainty.

## Early-warning indicators

For each scenario, name the observable signal that would show it is arriving — and specify it
precisely enough to be checked. "Regulatory pressure increases" is not observable. "A second
jurisdiction opens a consultation" is.

Assign each indicator an owner and a review cadence. Scenario work that produces no monitoring is a
workshop, not a plan.

## Revisit on the trigger, not the calendar

Most scenario planning is done once and filed. Its value comes from being revisited when an indicator
fires — that is the moment the earlier thinking pays, because the options were identified before
anyone was under pressure.

## Never

- Assign probabilities to scenarios and then plan only for the likeliest. That is forecasting with
  extra steps.
- Build a scenario nobody in the room believes possible. It will be ignored, and the exercise loses
  credibility.
- Let the exercise end without naming what to do on Monday in every scenario.

---

## 来源与署名 / Source & Attribution

本技能收录自 [cbrock84/headcount](https://github.com/cbrock84/headcount/tree/main/plugins/corporate-strategy/skills/scenario-planning)（MIT）；awesome-skillkit 仅做规范化（frontmatter 归一、补中文描述、路径与链接清理）与署名，内容与更新以上游为准。
