# Sources — `operations:service-level-management`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## Interagency Guidance on Third-Party Relationships: Risk Management

Federal Reserve, FDIC and OCC · US · public domain (US government) — quote freely

<https://www.federalreserve.gov/newsevents/pressreleases/bcreg20230606a.htm>

**Authoritative for:** What due diligence, contract terms, monitoring and termination planning a vendor relationship requires, scaled to how critical it is. The clearest published statement of the lifecycle, and the one regulated buyers will hold you to.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
