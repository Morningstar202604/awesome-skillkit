# Sources — `operations:vendor-management`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## Federal Acquisition Regulation

US General Services Administration, on behalf of the FAR Council · US · public domain (US government) — quote freely

<https://www.acquisition.gov/browse/index/far>

Machine-readable: <https://www.acquisition.gov/far/part-31>

**Authoritative for:** What a competitive sourcing process must do to be lawful — solicitation types, evaluation criteria, competition requirements, and how contract type allocates risk. Binding for federal buying and the reference everywhere else.

## ISO 9001 — Quality management systems: requirements

ISO · global · **sold — cite the identifier only, never the text**

<https://www.iso.org/standard/62085.html>

**Authoritative for:** Whether a quality system is certifiable — the auditable requirements a nonconformity procedure or management review is judged against. Sold, so cite the clause number and never the wording.

## Interagency Guidance on Third-Party Relationships: Risk Management

Federal Reserve, FDIC and OCC · US · public domain (US government) — quote freely

<https://www.federalreserve.gov/newsevents/pressreleases/bcreg20230606a.htm>

**Authoritative for:** What due diligence, contract terms, monitoring and termination planning a vendor relationship requires, scaled to how critical it is. The clearest published statement of the lifecycle, and the one regulated buyers will hold you to.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
