---
name: business-continuity-and-resilience
description: >-
  Plans for operating through disruption — impact analysis, recovery
  objectives, continuity plans, and the exercises that prove they work. Use
  this to run a business impact analysis, set RTO and RPO, write or test a
  continuity plan, prepare for a supplier or site failure, or answer a
  customer's resilience questionnaire.
description_zh: "业务连续性规划：影响分析、恢复目标、连续性预案与演练验证。"
license: MIT
compatibility: 纯提示型；涉及财务、合规或法律判断时建议人工复核。
metadata:
  author: "cbrock84/headcount 上游（MIT）"
  version: "1.0.0"
  category: ops
  pattern: single-task
  tier: standard
  verified-date: "2026-09-27"
  source: "https://github.com/cbrock84/headcount/tree/main/plugins/operations/skills/business-continuity-and-resilience"
---

# Business continuity and resilience

Continuity is a business question wearing technical clothing. The technical restore is covered by
`it-operations:backup-and-recovery`; this is about which processes must keep running, for whom, and
how long you can survive without them.

## Start with impact, not systems

A business impact analysis asks, per process: what breaks downstream, how fast, and who notices.
Work outward from the customer-visible failure, not inward from the asset register — an inventory of
systems tells you what you own, never what matters.

For each critical process establish:

- **Maximum tolerable outage** — the point past which the damage is not recoverable by working harder
  afterwards. This is a business judgment, made by the process owner, not by IT.
- **RTO** — how quickly it must be back. Always shorter than someone wants to pay for.
- **RPO** — how much data you can afford to lose, measured in time. An RPO of zero is a claim about
  spending, not about intent.

RTO and RPO that were not signed by the person accountable for the process are aspirations.

## Plans people can follow badly

A continuity plan is read by a stressed person at 03:00 who did not write it. Optimize for that
reader: named roles rather than names, decision authority stated explicitly, and the first three
actions on the first page.

Include what to do when the plan's assumptions fail — the alternate site is also affected, the key
person is unreachable, the supplier is not answering. Plans that only handle the anticipated failure
handle almost nothing.

## Exercises

Untested plans are documents, not capabilities. Escalate the rigour:

1. **Walkthrough** — read it aloud together and find the steps nobody can actually perform.
2. **Tabletop** — inject a scenario and make the decisions under time pressure.
3. **Live failover** — actually run on the alternate path, in production, with the real people.

The exercise produces findings or it was theater. Track them as work with owners and dates, and
re-run the scenario that failed rather than a fresh one, so improvement is demonstrable.

## Concentration risk

Resilience fails where dependencies converge invisibly: three suppliers who all sit on one cloud
region, redundant network paths in the same physical duct, a manual workaround that requires a
system you have just lost. Map dependencies to the point where they stop being yours, and check
whether the redundancy is real or just contractual.

## Sources

`references/sources.md` in this skill lists the outside authorities that settle the questions
here — what each one is authoritative for, and what you may do with it. Check them before
answering on anything they cover, and cite what you used. Most are free to read and not free
to reproduce; the use note on each is binding.

## Tooling

Continuity and crisis management platforms: Fusion Framework, Castellan, Riskonnect, and similar.
They hold the impact analysis, the plans, and the exercise record in one place, and they are worth
buying at the point where the plans are too many for one person to keep current.

Mass notification: Everbridge, AlertMedia, and similar — the capability being bought is reaching
people when your own email and chat are the thing that is down, which is the scenario a plan stored
only in those systems fails.

Keep an offline copy of the plan and the contact list. Every organization that has run a real
incident has a story about the plan being inside the system that was unavailable.

## Never

- Set an RTO without the process owner agreeing to what it costs.
- Count a plan as tested because it was reviewed.
- Treat a backup as continuity — an unrestored backup is an untested assumption.
- Write a plan whose first step requires the system that has just failed.

---

## 来源与署名 / Source & Attribution

本技能收录自 [cbrock84/headcount](https://github.com/cbrock84/headcount/tree/main/plugins/operations/skills/business-continuity-and-resilience)（MIT）；awesome-skillkit 仅做规范化（frontmatter 归一、补中文描述、路径与链接清理）与署名，内容与更新以上游为准。
