# Sources — `pmo:dependency-and-risk-management`

<!-- Generated upstream by build-sources.py from the source catalog. Do not edit. -->

Check these before answering on anything they cover, and cite what you used. The use note on each one is binding: most of what a professional cites is free to read and not free to reproduce.

## GAO Schedule Assessment Guide: best practices for project schedules

US Government Accountability Office · US · public domain (US government) — quote freely

<https://www.gao.gov/products/gao-16-89g>

Machine-readable: <https://www.gao.gov/assets/gao-16-89g.pdf>

**Authoritative for:** Whether a schedule is reliable — the ten criteria an auditor applies, covering the work breakdown, sequencing, resource loading, critical path, total float and schedule risk analysis.

---

Sources are maintained in `sources/` upstream, not here. If one is wrong, out of date, or missing, fix it there — this file is regenerated and an edit to it is lost.
