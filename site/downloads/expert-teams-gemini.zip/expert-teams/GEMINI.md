# AI Expert Teams（Gemini CLI 扩展上下文）

本扩展由 `export-platforms.py` 从平台中立源格式导出。

## 用法

- 用 `/<team-name> <任务>` 调起对应团队的 team-lead（如 `/marketing-team 做个 618 方案`）。
- lead 按 `{{args}}` 接收任务，负责拆解、派单、门禁与交接。

## 编排纪律

所有 lead 统一遵循仓库根目录 `orchestration-protocol.md`：
质量门禁（H 级不交付）、回炉≤2 次、断路切换、四块交接、技能回退。

## 团队路由

| 命令 | 团队 |
| --- | --- |
| `/academic-paper-team` | academic-paper-team |
| `/audio-podcast-team` | audio-podcast-team |
| `/content-writing-team` | content-writing-team |
| `/data-analysis-team` | data-analysis-team |
| `/ecommerce-ops-team` | ecommerce-ops-team |
| `/education-training-team` | education-training-team |
| `/finance-team` | finance-team |
| `/fullstack-web-team` | fullstack-web-team |
| `/game-design-team` | game-design-team |
| `/hr-team` | hr-team |
| `/legal-compliance-team` | legal-compliance-team |
| `/marketing-team` | marketing-team |
| `/math-modeling-team` | math-modeling-team |
| `/product-team` | product-team |
| `/software-dev-team` | software-dev-team |
| `/translation-team` | translation-team |
| `/video-production-team` | video-production-team |
| `/visual-design-team` | visual-design-team |

## Skills

18 支团队的 skills 已随包导出至 `skills/`，按需读取对应 SKILL.md。
